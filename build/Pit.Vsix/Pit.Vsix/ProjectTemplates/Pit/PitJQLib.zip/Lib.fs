﻿namespace Pit
open Pit
open Pit.Dom
open Pit.Javascript.JQuery

module  Lib =
    [<Js>]
    let test() =
        jQuery.ofVal("<input type='button' value='hello world'/>")
        |> jQuery.appendTo("body")
        |> jQuery.click2(fun e -> alert("hello world"))        
        |> jQuery.ignore